package inClassAnonClass.LAMBDA_FI_CALCULATOR;



public class CalcMain {

	public static void main(String[] args) {
		
		System.out.println("Hello, tell me your first number?");
	
		MyCalc x = new MyCalc();
		
		int num1 = 5;
		int num2 = 10;
		
		System.out.println(x.sum.compute(num1,num2));
	
		
		System.out.println("\r\nresult should be above this line");
	}

}
